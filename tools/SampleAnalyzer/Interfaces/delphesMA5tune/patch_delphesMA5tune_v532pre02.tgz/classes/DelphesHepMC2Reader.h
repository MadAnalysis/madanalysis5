/*
 *  Delphes: a framework for fast simulation of a generic collider experiment
 *  Copyright (C) 2012-2014  Universite catholique de Louvain (UCL), Belgium
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef DelphesHepMC2Reader_h
#define DelphesHepMC2Reader_h

/** \class DelphesHepMC2Reader
 *
 *  Reads HepMC file
 *
 *  \author P. Demin - UCL, Louvain-la-Neuve
 *
 */

#include <map>
#include <vector>

#include <cstdio>

#include "TObject.h"

class TObjArray;
class TStopwatch;
class TDatabasePDG;
class ExRootTreeBranch;
class DelphesFactory;

class DelphesHepMC2Reader: public TObject
{
public:
  DelphesHepMC2Reader();
  ~DelphesHepMC2Reader();

  void OpenInputFile(const char *inputFileName);
  void CloseInputFile();

  void SetInputFile(FILE *inputFile);

  void Clear();
  bool EventReady();

  bool ReadEvent(DelphesFactory *factory,
    TObjArray *allParticleOutputArray,
    TObjArray *stableParticleOutputArray,
    TObjArray *partonOutputArray);

  [[deprecated("ReadBlock has been renamed to ReadEvent")]]
  bool ReadBlock(DelphesFactory *factory,
    TObjArray *allParticleOutputArray,
    TObjArray *stableParticleOutputArray,
    TObjArray *partonOutputArray)
  {
    return ReadEvent(factory, allParticleOutputArray, stableParticleOutputArray, partonOutputArray);
  }

  void AnalyzeEvent(ExRootTreeBranch *branch, long long eventNumber,
    TStopwatch *readStopWatch = 0, TStopwatch *procStopWatch = 0);

  void AnalyzeWeight(ExRootTreeBranch *branch);

private:
  void AnalyzeParticle(DelphesFactory *factory,
    TObjArray *allParticleOutputArray,
    TObjArray *stableParticleOutputArray,
    TObjArray *partonOutputArray);

  void FinalizeParticles(TObjArray *allParticleOutputArray);

  FILE *fInputFile;
  bool fIsOwner;

  char *fBuffer;

  TDatabasePDG *fPDG;

  int fEventNumber, fMPI, fProcessID, fSignalCode, fVertexCounter, fBeamCode[2];
  double fScale, fAlphaQCD, fAlphaQED;

  double fMomentumCoefficient, fPositionCoefficient;

  int fStateSize;
  std::vector<int> fState;

  int fWeightSize;
  std::vector<double> fWeight;

  //BEGIN MA5
  int fMA5index;
  // END MA5

  double fCrossSection, fCrossSectionError;

  int fID1, fID2;
  double fX1, fX2, fScalePDF, fPDF1, fPDF2;

  int fOutVertexCode, fVertexID, fInCounter, fOutCounter;
  double fX, fY, fZ, fT;

  int fParticleCode, fPID, fStatus, fInVertexCode;
  double fPx, fPy, fPz, fE, fMass, fTheta, fPhi;

  int fParticleCounter;

  std::map<int, std::pair<int, int> > fMotherMap;
  std::map<int, std::pair<int, int> > fDaughterMap;

  ClassDef(DelphesHepMC2Reader, 1)
};

#endif // DelphesHepMC2Reader_h
